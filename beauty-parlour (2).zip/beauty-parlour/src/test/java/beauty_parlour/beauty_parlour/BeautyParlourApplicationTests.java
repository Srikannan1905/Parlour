package beauty_parlour.beauty_parlour;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeautyParlourApplicationTests {

	@Test
	void contextLoads() {
	}

}
