-- users
CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  email VARCHAR(200) UNIQUE NOT NULL,
  password_hash VARCHAR(200) NOT NULL,
  role VARCHAR(50),
  full_name VARCHAR(200),
  phone VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- services
CREATE TABLE services (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  category VARCHAR(100),
  description TEXT,
  duration_minutes INT NOT NULL,
  price_cents INT NOT NULL,
  image_url TEXT,
  active BOOLEAN DEFAULT true
);

-- staff_profiles
CREATE TABLE staff_profiles (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT UNIQUE REFERENCES users(id),
  specialties TEXT,
  phone VARCHAR(50)
);

-- appointments
CREATE TABLE appointments (
  id BIGSERIAL PRIMARY KEY,
  customer_id BIGINT REFERENCES users(id),
  staff_id BIGINT REFERENCES staff_profiles(id),
  service_id BIGINT REFERENCES services(id),
  start_time TIMESTAMP WITH TIME ZONE,
  end_time TIMESTAMP WITH TIME ZONE,
  status VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  notes TEXT
);

-- Seed admin user (password: adminpass)
INSERT INTO users (username, email, password_hash, role, full_name) VALUES
('admin', 'admin@parlour.local', '$2a$10$P1y0gq6G1fO7aJmT9Qw5EeCk8o1T4nWwR0mKzY2Q7B4gxN7r9tG9e', 'ROLE_ADMIN', 'Admin Manager');

-- Seed a customer (password: customer)
INSERT INTO users (username, email, password_hash, role, full_name) VALUES
('customer', 'cust@example.com', '$2a$10$k0b0L8u7VZ/1P8Gq1ZsFxeCx1Hq9y8oJwVnOa2Y3fE4sL7pU9aT7e', 'ROLE_CUSTOMER', 'Demo Customer');

-- Seed services
INSERT INTO services (name, category, description, duration_minutes, price_cents, image_url) VALUES
('Classic Haircut', 'Haircut', 'A traditional haircut with wash and finish.', 30, 499, ''),
('Signature Facial', 'Facial', 'Deep cleansing facial for glowing skin.', 60, 999, '');

-- Create a stylist user & profile (password: stylistpass)
INSERT INTO users (username, email, password_hash, role, full_name) VALUES
('stylist', 'stylist@parlour.local', '$2a$10$Vb7lq3dC8pO5Z1xQ3rT2JeZq1Y8w6sXn3uHf9gM2yE4cR0qP1lF2e', 'ROLE_STYLIST', 'Sofia Stylist');

INSERT INTO staff_profiles (user_id, specialties, phone) VALUES
((SELECT id FROM users WHERE username='stylist'), 'Haircut,Facial', '9999999999');
