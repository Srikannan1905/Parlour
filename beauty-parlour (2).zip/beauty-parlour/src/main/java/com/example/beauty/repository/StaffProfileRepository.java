package com.example.beauty.repository;

import com.example.beauty.model.StaffProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface StaffProfileRepository extends JpaRepository<StaffProfile, Long> {
    List<StaffProfile> findAll();
}
