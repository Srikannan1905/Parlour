package com.example.beauty.service;

import com.example.beauty.model.*;
import com.example.beauty.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService {
    private final AppointmentRepository appointmentRepository;
    private final StaffProfileRepository staffRepository;
    private final ServiceRepository serviceRepository;
    private static final int DEFAULT_BUFFER_MINUTES = 10;
    private static final int DEFAULT_LEAD_MINUTES = 60;

    public BookingService(AppointmentRepository appointmentRepository,
                          StaffProfileRepository staffRepository,
                          ServiceRepository serviceRepository) {
        this.appointmentRepository = appointmentRepository;
        this.staffRepository = staffRepository;
        this.serviceRepository = serviceRepository;
    }

    public List<ServiceEntity> listActiveServices() {
        return serviceRepository.findByActiveTrue();
    }

    @Transactional
    public Appointment book(Long customerId, Long serviceId, OffsetDateTime startTime, StaffProfile preferredStaff, User customer) {
        ServiceEntity svc = serviceRepository.findById(serviceId)
                .orElseThrow(() -> new IllegalArgumentException("Service not found"));

        // enforce lead time
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.systemDefault());
        if (startTime.isBefore(now.plusMinutes(DEFAULT_LEAD_MINUTES))) {
            throw new IllegalArgumentException("Booking must be made at least " + DEFAULT_LEAD_MINUTES + " minutes in advance");
        }

        int totalMinutes = svc.getDurationMinutes() + DEFAULT_BUFFER_MINUTES;
        OffsetDateTime endTime = startTime.plus(totalMinutes, ChronoUnit.MINUTES);

        // if preferredStaff provided check availability
        StaffProfile assigned = null;
        if (preferredStaff != null) {
            List<Appointment> conflicts = appointmentRepository.findOverlappingForStaff(preferredStaff, startTime, endTime);
            if (!conflicts.isEmpty()) throw new IllegalArgumentException("Preferred staff not available at this time");
            assigned = preferredStaff;
        } else {
            // find any staff
            for (StaffProfile sp : staffRepository.findAll()) {
                List<Appointment> conflicts = appointmentRepository.findOverlappingForStaff(sp, startTime, endTime);
                if (conflicts.isEmpty()) { assigned = sp; break; }
            }
            if (assigned == null) throw new IllegalArgumentException("No staff available at this time");
        }

        Appointment appt = new Appointment();
        appt.setCustomer(customer);
        appt.setStaff(assigned);
        appt.setService(svc);
        appt.setStartTime(startTime);
        appt.setEndTime(endTime);
        appt.setStatus("BOOKED");
        return appointmentRepository.save(appt);
    }

    public List<Appointment> findByCustomer(Long customerId) {
        return appointmentRepository.findByCustomerId(customerId);
    }
}
