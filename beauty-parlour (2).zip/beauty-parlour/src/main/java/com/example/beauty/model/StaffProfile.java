package com.example.beauty.model;

import jakarta.persistence.*;

@Entity
@Table(name = "staff_profiles")
public class StaffProfile {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id", unique = true)
    private User user;

    // a simple CSV of categories or service ids for MVP
    @Column(length = 500)
    private String specialties;

    private String phone;

    // getters & setters...
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    public String getSpecialties() { return specialties; }
    public void setSpecialties(String specialties) { this.specialties = specialties; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}
