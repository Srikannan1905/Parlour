package com.example.beauty.controller;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.beauty.dto.BookingRequest;
import com.example.beauty.model.Appointment;
import com.example.beauty.model.ServiceEntity;
import com.example.beauty.model.StaffProfile;
import com.example.beauty.model.User;
import com.example.beauty.repository.ServiceRepository;
import com.example.beauty.repository.StaffProfileRepository;
import com.example.beauty.repository.UserRepository;
import com.example.beauty.service.BookingService;

@Controller
public class BookingController {
	private final BookingService bookingService;
	private final UserRepository userRepository;
	private final StaffProfileRepository staffRepo;
	private final ServiceRepository serviceRepository;

	public BookingController(BookingService bookingService, UserRepository userRepository,
			StaffProfileRepository staffRepo, ServiceRepository serviceRepository) {
		this.bookingService = bookingService;
		this.userRepository = userRepository;
		this.staffRepo = staffRepo;
		this.serviceRepository = serviceRepository;
	}

	@GetMapping("/book")
	public String bookForm(@RequestParam Long serviceId, Model model) {
		model.addAttribute("service", serviceRepository.findById(serviceId).orElseThrow());
		model.addAttribute("staff", staffRepo.findAll());
		model.addAttribute("booking", new BookingRequest());
		return "book";
	}

	@PostMapping("/appointments")
	public String createBooking(@ModelAttribute BookingRequest booking,
			@AuthenticationPrincipal UserDetails userDetails, Model model) {
		try {
			User user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow();
			ServiceEntity svc = serviceRepository.findById(booking.getServiceId()).orElseThrow();
			StaffProfile preferred = null;
			if (booking.getStaffId() != null) {
				preferred = staffRepo.findById(booking.getStaffId()).orElse(null);
			}
			OffsetDateTime start = OffsetDateTime.parse(booking.getStartTime(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
			Appointment appt = bookingService.book(user.getId(), svc.getId(), start, preferred, user);
			return "redirect:/dashboard";
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			model.addAttribute("service", serviceRepository.findById(booking.getServiceId()).orElse(null));
			model.addAttribute("staff", staffRepo.findAll());
			return "book";
		}
	}

	@GetMapping("/dashboard")
	public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
		User user = userRepository.findByUsername(userDetails.getUsername()).orElseThrow();
		model.addAttribute("appointments", bookingService.findByCustomer(user.getId()));
		return "dashboard";
	}
}
