package com.example.beauty.repository;

import com.example.beauty.model.Appointment;
import com.example.beauty.model.StaffProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.OffsetDateTime;
import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByCustomerId(Long customerId);

    @Query("select a from Appointment a where a.staff = :staff and a.status <> 'CANCELLED' and " +
           "(:start < a.endTime and :end > a.startTime)")
    List<Appointment> findOverlappingForStaff(StaffProfile staff, OffsetDateTime start, OffsetDateTime end);

    @Query("select a from Appointment a where a.status <> 'CANCELLED' and " +
           "(:start < a.endTime and :end > a.startTime)")
    List<Appointment> findOverlappingAnyStaff(OffsetDateTime start, OffsetDateTime end);
}
