package com.example.beauty.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.example.beauty.repository.UserRepository;

@Configuration
public class SecurityConfig {

	private final UserRepository userRepository;

	public SecurityConfig(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Bean
	public UserDetailsService userDetailsService() {
		return username -> userRepository.findByUsername(username)
				.map(u -> org.springframework.security.core.userdetails.User.withUsername(u.getUsername())
						.password(u.getPasswordHash()).roles(u.getRole().name().replace("ROLE_", "")).build())
				.orElseThrow(() -> new UsernameNotFoundException("User not found"));
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.authorizeHttpRequests(auth -> auth
				.requestMatchers("/css/**", "/", "/services", "/services/**", "/register", "/login", "/h2-console/**")
				.permitAll().requestMatchers("/admin/**").hasRole("ADMIN").anyRequest().authenticated())
				.formLogin(form -> form.loginPage("/login").permitAll()).logout(logout -> logout.permitAll())
				.csrf(csrf -> csrf.ignoringRequestMatchers("/h2-console/**"))
				.headers(headers -> headers.frameOptions().sameOrigin());

		return http.build();
	}
	protected void configure(HttpSecurity http) throws Exception { // Spring Security 5 style example
	    http.authorizeRequests()
	        .requestMatchers("/css/**", "/", "/index", "/login", "/h2-console/**", "/register", "/error").permitAll()
	        .anyRequest().authenticated()
	        .and().formLogin().loginPage("/login").permitAll()
	        .and().logout().permitAll();

	    // for H2 console in dev
	    http.csrf().ignoringRequestMatchers(new AntPathRequestMatcher("/h2-console/**"));
	    http.headers().frameOptions().sameOrigin();
	}

}
