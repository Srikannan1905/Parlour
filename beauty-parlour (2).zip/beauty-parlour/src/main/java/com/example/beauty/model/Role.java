package com.example.beauty.model;

public enum Role {
    ROLE_CUSTOMER,
    ROLE_STYLIST,
    ROLE_ADMIN
}
