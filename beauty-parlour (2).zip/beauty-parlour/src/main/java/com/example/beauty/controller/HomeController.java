package com.example.beauty.controller;

import com.example.beauty.service.BookingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
	private final BookingService bookingService;

	public HomeController(BookingService bookingService) {
		this.bookingService = bookingService;
	}

	@GetMapping("/index")
	public String index(Model model) {
		model.addAttribute("services", bookingService.listActiveServices());
		return "index";
	}

	@GetMapping("/")
	public String home(Model model) {
		model.addAttribute("pageTitle", "Beauty Parlour");
		return "index";
	}

}
