package com.example.beauty.dto;

public class BookingRequest {
    private Long serviceId;
    private Long staffId;
    private String startTime; // ISO_OFFSET_DATE_TIME string, e.g., "2025-11-21T10:30:00+05:30"
    private String notes;

    // getters/setters
    public Long getServiceId() { return serviceId; }
    public void setServiceId(Long serviceId) { this.serviceId = serviceId; }
    public Long getStaffId() { return staffId; }
    public void setStaffId(Long staffId) { this.staffId = staffId; }
    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
