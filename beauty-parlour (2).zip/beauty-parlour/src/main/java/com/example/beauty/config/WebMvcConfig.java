package com.example.beauty.config;

public class WebMvcConfig {

}
