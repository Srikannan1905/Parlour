package com.example.beauty.controller;

import com.example.beauty.model.ServiceEntity;
import com.example.beauty.repository.ServiceRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/services")
public class ServiceController {
    private final ServiceRepository serviceRepository;
    public ServiceController(ServiceRepository serviceRepository) { this.serviceRepository = serviceRepository; }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("services", serviceRepository.findByActiveTrue());
        return "services";
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        ServiceEntity svc = serviceRepository.findById(id).orElseThrow();
        model.addAttribute("service", svc);
        return "service-detail";
    }
}
